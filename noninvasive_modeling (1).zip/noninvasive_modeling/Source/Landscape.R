LandscapeInit = function(landscape){
  #set up object
  land  = matrix(nrow=landscape, ncol=landscape)
  
  #I can add land features later in this

  #return land object
  return(land)
}
